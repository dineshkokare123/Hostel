<header id="header" class="alt">
					<h1><a href="index.php">MIT</a> Hostels</h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li>
								
							</li>
							<li><a href="login.php" class="button">LogIn</a></li>
						</ul>
					</nav>
				</header>