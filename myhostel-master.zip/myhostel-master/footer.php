<footer id="footer">
					<ul class="copyright">
						<li>Disclaimer : This website is a personal project. Not an official MIT Manipal site.</li><br><br><li>Developer: <a href="http://abhinavagrawal.in">gR00T</a></li>
					</ul>
				</footer>